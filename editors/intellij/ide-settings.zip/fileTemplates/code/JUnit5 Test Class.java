import static org.junit.jupiter.api.Assertions.*;
#parse("File Header.java")
final class ${NAME} {
  ${BODY}
}